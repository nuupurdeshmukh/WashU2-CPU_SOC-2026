# Week 1 — Starter Library

These files support the Week 1 modules. You do **not** write the gates in
`gates/` — they are given to you so you can focus on *connecting* blocks and
learning the simulation workflow (Module 4).

## What's here

```
starter_library/
├── gates/                  # provided basic components (DO NOT modify)
│   ├── and_gate.vhd
│   ├── or_gate.vhd
│   ├── not_gate.vhd
│   ├── xor_gate.vhd
│   └── nand_gate.vhd
└── testbenches/            # provided working testbenches
    ├── tb_and_gate.vhd     # test the basic gates (Modules 3/5/6)
    ├── tb_or_gate.vhd
    ├── tb_not_gate.vhd
    ├── tb_xor_gate.vhd
    ├── tb_nand_gate.vhd
    ├── tb_xor_structural.vhd   # for Exercise 1 (you build xor_structural)
    ├── tb_mux2.vhd             # for Exercise 2 (you build mux2)
    └── tb_half_adder.vhd       # for Exercise 3 (you build half_adder)
```

## How to use these

1. **Module 3 (toolchain test):** add `gates/and_gate.vhd` and
   `testbenches/tb_and_gate.vhd` to a Quartus project, compile, and run RTL
   simulation. Seeing the AND waveform confirms your tools work.

2. **Module 4 (guided exercises):** you build `xor_structural`, `mux2`, and
   `half_adder` yourself by connecting the provided gates. The matching
   `tb_*.vhd` files in `testbenches/` are the **provided working
   testbenches** — you do not write these; you just run them against your
   designs and check the waveform.

3. **Module 6 (write your own testbench):** you write testbenches for the
   XOR gate, NAND gate, and half adder *yourself*. The provided
   `tb_xor_gate.vhd` / `tb_nand_gate.vhd` / `tb_half_adder.vhd` can be used
   afterward to compare against your own attempt — try first, compare second.

## Naming your designs

So the provided testbenches connect correctly, use these exact entity and
port names when you build the Exercise designs:

| Exercise | Entity name | Ports |
|---|---|---|
| 1 | `xor_structural` | `a, b : in` ; `y : out` |
| 2 | `mux2` | `a, b, sel : in` ; `y : out` |
| 3 | `half_adder` | `a, b : in` ; `sum, carry : out` |

If your ports are named differently, the `port map` in the provided testbench
won't match and you'll get a compile error — match these names.

## Rule

Do not modify anything in `gates/`. Treat it as a sealed parts bin. The whole
point of Week 1 is composing given parts and learning the workflow.
